/* ===========================
   contato.js — Validação de formulário de contato
   (Requisito de JS: validação de campos via JavaScript)
=========================== */

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('contato-form');
  const feedback = document.getElementById('form-feedback');

  if (!form) return;

  /* =========================================================
     1. FUNÇÕES DE VALIDAÇÃO
  ========================================================= */

  function validarCampoTexto(input, minLen = 2) {
    const errorEl = document.getElementById(`erro-${input.id}`);
    const valor = input.value.trim();
    let mensagem = '';

    if (valor === '') {
      mensagem = 'Este campo é obrigatório.';
    } else if (valor.length < minLen) {
      mensagem = `Mínimo de ${minLen} caracteres.`;
    }

    if (mensagem) {
      input.classList.add('invalid');
      input.setAttribute('aria-invalid', 'true');
      if (errorEl) {
        errorEl.textContent = mensagem;
        errorEl.setAttribute('role', 'alert');
      }
      return false;
    }

    input.classList.remove('invalid');
    input.setAttribute('aria-invalid', 'false');
    if (errorEl) errorEl.textContent = '';
    return true;
  }

  function validarEmail(input) {
    const errorEl = document.getElementById(`erro-${input.id}`);
    const valor = input.value.trim();
    const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let mensagem = '';

    if (valor === '') {
      mensagem = 'O e-mail é obrigatório.';
    } else if (!regexEmail.test(valor)) {
      mensagem = 'Informe um e-mail válido (ex: nome@email.com).';
    }

    if (mensagem) {
      input.classList.add('invalid');
      input.setAttribute('aria-invalid', 'true');
      if (errorEl) {
        errorEl.textContent = mensagem;
        errorEl.setAttribute('role', 'alert');
      }
      return false;
    }

    input.classList.remove('invalid');
    input.setAttribute('aria-invalid', 'false');
    if (errorEl) errorEl.textContent = '';
    return true;
  }

  function validarSelect(select) {
    const errorEl = document.getElementById(`erro-${select.id}`);
    let mensagem = '';

    if (!select.value) {
      mensagem = 'Selecione um assunto.';
    }

    if (mensagem) {
      select.classList.add('invalid');
      select.setAttribute('aria-invalid', 'true');
      if (errorEl) {
        errorEl.textContent = mensagem;
        errorEl.setAttribute('role', 'alert');
      }
      return false;
    }

    select.classList.remove('invalid');
    select.setAttribute('aria-invalid', 'false');
    if (errorEl) errorEl.textContent = '';
    return true;
  }

  function validarMensagem(textarea) {
    const errorEl = document.getElementById(`erro-${textarea.id}`);
    const valor = textarea.value.trim();
    let mensagem = '';

    if (valor === '') {
      mensagem = 'A mensagem é obrigatória.';
    } else if (valor.length < 20) {
      mensagem = 'A mensagem deve ter pelo menos 20 caracteres.';
    }

    if (mensagem) {
      textarea.classList.add('invalid');
      textarea.setAttribute('aria-invalid', 'true');
      if (errorEl) {
        errorEl.textContent = mensagem;
        errorEl.setAttribute('role', 'alert');
      }
      return false;
    }

    textarea.classList.remove('invalid');
    textarea.setAttribute('aria-invalid', 'false');
    if (errorEl) errorEl.textContent = '';
    return true;
  }

  /* =========================================================
     2. LIMPEZA DE ERRO AO DIGITAR
  ========================================================= */

  const campos = form.querySelectorAll('input, select, textarea');
  campos.forEach((campo) => {
    const evento = campo.tagName === 'SELECT' ? 'change' : 'input';
    campo.addEventListener(evento, () => {
      campo.classList.remove('invalid');
      campo.setAttribute('aria-invalid', 'false');
      const errorEl = document.getElementById(`erro-${campo.id}`);
      if (errorEl) errorEl.textContent = '';
    });
  });

  /* =========================================================
     3. SUBMIT — validação completa e envio simulado
  ========================================================= */

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const nome = document.getElementById('nome');
    const email = document.getElementById('email');
    const assunto = document.getElementById('assunto');
    const mensagem = document.getElementById('mensagem');

    const valido =
      validarCampoTexto(nome, 2) &
      validarEmail(email) &
      validarSelect(assunto) &
      validarMensagem(mensagem);

    if (!valido) {
      // Foca o primeiro campo inválido para acessibilidade
      const primeiroInvalido = form.querySelector('.invalid');
      if (primeiroInvalido) primeiroInvalido.focus();
      return;
    }

    // Simula envio
    const btnSubmit = form.querySelector('[type="submit"]');
    btnSubmit.disabled = true;
    btnSubmit.textContent = 'Enviando...';

    setTimeout(() => {
      form.reset();
      btnSubmit.disabled = false;
      btnSubmit.textContent = 'Enviar mensagem';

      // Exibe mensagem de sucesso no DOM
      feedback.hidden = false;
      feedback.setAttribute('role', 'alert');
      feedback.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

      // Oculta após 6 segundos
      setTimeout(() => {
        feedback.hidden = true;
      }, 6000);
    }, 1200);
  });
});
