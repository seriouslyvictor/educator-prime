/* ===========================
   catalogo.js — Renderização dinâmica do catálogo
   (Requisito de JS: array de objetos + loops)
=========================== */

document.addEventListener('DOMContentLoaded', () => {
  const grid = document.getElementById('catalogo-grid');
  const filterButtons = document.querySelectorAll('.filter-btn');
  const emptyState = document.getElementById('catalogo-empty');
  const resultCount = document.getElementById('catalogo-count');

  if (!grid) return;

  let filtroAtivo = 'todos';

  /**
   * Retorna um rótulo amigável para o objetivo.
   */
  function rotuloObjetivo(objetivo) {
    const rotulos = {
      hipertrofia: 'Ganho de massa',
      emagrecimento: 'Emagrecimento',
      manutenção: 'Manutenção'
    };
    return rotulos[objetivo] || objetivo;
  }

  /**
   * Retorna um rótulo amigável para o tipo.
   */
  function rotuloTipo(tipo) {
    return tipo === 'treino' ? 'Treino' : 'Receita';
  }

  /**
   * Cria o elemento DOM (card) para um item do catálogo.
   */
  function criarCard(item) {
    const card = document.createElement('article');
    card.className = 'card catalog-card fade-in';
    card.onclick = () => {window.location.href = "treino-pernas.html"}

    card.innerHTML = `
      <div class="card-image">
        <img src="${item.imagem}" alt="${item.nome}" loading="lazy" />
      </div>
      <div class="card-tags">
        <span class="badge">${rotuloObjetivo(item.objetivo)}</span>
        <span class="badge badge-muted">${rotuloTipo(item.tipo)}</span>
        <span class="badge badge-muted">${item.dificuldade}</span>
      </div>
      <h3>${item.nome}</h3>
      <p>${item.descricao}</p>
    `;

    return card;
  }

  /**
   * Renderiza os itens do catálogo na tela, aplicando o filtro ativo.
   * Usa um loop (for...of) sobre o array de objetos, conforme
   * requisito do PRD (Array 1 - Catálogo de Saúde).
   */
  function renderizarCatalogo() {
    grid.innerHTML = '';

    const itensFiltrados = [];

    for (const item of catalogoSaude) {
      if (filtroAtivo === 'todos' || item.objetivo === filtroAtivo) {
        itensFiltrados.push(item);
      }
    }

    if (itensFiltrados.length === 0) {
      emptyState.hidden = false;
    } else {
      emptyState.hidden = true;
      for (const item of itensFiltrados) {
        grid.appendChild(criarCard(item));
      }
    }

    if (resultCount) {
      resultCount.textContent = `${itensFiltrados.length} item${itensFiltrados.length === 1 ? '' : 's'} encontrado${itensFiltrados.length === 1 ? '' : 's'}`;
    }

    ativarFadeIn();
  }

  /**
   * Reaplica a animação de fade-in para os cards recém-criados.
   */
  function ativarFadeIn() {
    const fadeElements = grid.querySelectorAll('.fade-in');

    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('visible');
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.1 }
      );
      fadeElements.forEach((el) => observer.observe(el));
    } else {
      fadeElements.forEach((el) => el.classList.add('visible'));
    }
  }

  /**
   * Configura os botões de filtro (Ganho de Massa / Emagrecimento / etc).
   */
  filterButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      filterButtons.forEach((b) => {
        b.classList.remove('active');
        b.setAttribute('aria-pressed', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-pressed', 'true');

      filtroAtivo = btn.dataset.filter;
      renderizarCatalogo();
    });
  });

  // Renderização inicial
  renderizarCatalogo();
});