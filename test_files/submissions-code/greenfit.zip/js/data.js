/* ===========================
   data.js — Catálogo de Saúde (GreenFit)
   Array de objetos: treinos e receitas fit
=========================== */

const catalogoSaude = [
  // ---------- TREINOS - HIPERTROFIA ----------
  {
    id: 1,
    nome: "Treino de Peito e Tríceps",
    tipo: "treino",
    objetivo: "hipertrofia",
    dificuldade: "intermediário",
    imagem: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop",
    descricao: "Supino reto, supino inclinado, crucifixo e tríceps testa. 4 séries de 8-12 repetições, foco em volume muscular."
  },
  {
    id: 2,
    nome: "Treino de Pernas Completo",
    tipo: "treino",
    objetivo: "hipertrofia",
    dificuldade: "avançado",
    imagem: "https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&h=300&fit=crop",
    descricao: "Agachamento livre, leg press, cadeira extensora e stiff. Treino intenso para quadríceps, glúteos e posteriores."
  },
  {
    id: 3,
    nome: "Treino de Costas e Bíceps",
    tipo: "treino",
    objetivo: "hipertrofia",
    dificuldade: "intermediário",
    imagem: "https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=400&h=300&fit=crop",
    descricao: "Puxada frontal, remada curvada, rosca direta e rosca alternada. Foco em largura e espessura das costas."
  },
  {
    id: 4,
    nome: "Treino de Ombro e Abdômen",
    tipo: "treino",
    objetivo: "hipertrofia",
    dificuldade: "iniciante",
    imagem: "https://images.unsplash.com/photo-1581009137042-c552e485697a?w=400&h=300&fit=crop",
    descricao: "Desenvolvimento com halteres, elevação lateral e prancha abdominal. Ideal para começar a fortalecer o tronco."
  },

  // ---------- TREINOS - EMAGRECIMENTO ----------
  {
    id: 5,
    nome: "HIIT Full Body 20 minutos",
    tipo: "treino",
    objetivo: "emagrecimento",
    dificuldade: "intermediário",
    imagem: "https://images.unsplash.com/photo-1554344728-77cf90d9ed26?w=400&h=300&fit=crop",
    descricao: "Circuito de alta intensidade: burpees, mountain climbers, polichinelos e agachamento com salto. 4 rodadas."
  },
  {
    id: 6,
    nome: "Caminhada + Corrida Intervalada",
    tipo: "treino",
    objetivo: "emagrecimento",
    dificuldade: "iniciante",
    imagem: "https://images.unsplash.com/photo-1486218119243-13883505764c?w=400&h=300&fit=crop",
    descricao: "5 minutos de caminhada leve, seguidos de 1 minuto de corrida e 2 de caminhada, por 30 minutos."
  },
  {
    id: 7,
    nome: "Treino Funcional com Peso Corporal",
    tipo: "treino",
    objetivo: "emagrecimento",
    dificuldade: "avançado",
    imagem: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=400&h=300&fit=crop",
    descricao: "Flexões, afundos, escaladores e prancha dinâmica em formato de circuito, sem necessidade de equipamentos."
  },

  // ---------- TREINOS - MANUTENÇÃO ----------
  {
    id: 8,
    nome: "Treino de Mobilidade e Alongamento",
    tipo: "treino",
    objetivo: "manutenção",
    dificuldade: "iniciante",
    imagem: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&h=300&fit=crop",
    descricao: "Sequência de alongamentos dinâmicos e mobilidade articular, ideal para dias de recuperação ativa."
  },
  {
    id: 9,
    nome: "Treino Full Body Equilibrado",
    tipo: "treino",
    objetivo: "manutenção",
    dificuldade: "intermediário",
    imagem: "https://images.unsplash.com/photo-1765302741884-e846c7a178df?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    descricao: "Combinação de exercícios para todos os grupos musculares, 3x na semana, mantendo força e disposição."
  },

  // ---------- RECEITAS - HIPERTROFIA ----------
  {
    id: 10,
    nome: "Omelete Proteico com Aveia",
    tipo: "alimentação",
    objetivo: "hipertrofia",
    dificuldade: "fácil",
    imagem: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=400&h=300&fit=crop",
    descricao: "3 ovos, aveia em flocos, espinafre e queijo cottage. Rico em proteínas para auxiliar na recuperação muscular."
  },
  {
    id: 11,
    nome: "Frango Grelhado com Batata Doce",
    tipo: "alimentação",
    objetivo: "hipertrofia",
    dificuldade: "fácil",
    imagem: "https://images.unsplash.com/photo-1532550907401-a500c9a57435?w=400&h=300&fit=crop",
    descricao: "Peito de frango grelhado, batata doce assada e brócolis no vapor. Clássico para ganho de massa magra."
  },
  {
    id: 12,
    nome: "Shake Pós-Treino de Banana e Pasta de Amendoim",
    tipo: "alimentação",
    objetivo: "hipertrofia",
    dificuldade: "fácil",
    imagem: "https://images.unsplash.com/photo-1622597467836-f3285f2131b8?w=400&h=300&fit=crop",
    descricao: "Banana, leite, whey protein e pasta de amendoim batidos. Reposição rápida de energia e proteína."
  },

  // ---------- RECEITAS - EMAGRECIMENTO ----------
  {
    id: 13,
    nome: "Salada de Folhas com Grão-de-Bico",
    tipo: "alimentação",
    objetivo: "emagrecimento",
    dificuldade: "fácil",
    imagem: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop",
    descricao: "Mix de folhas verdes, grão-de-bico cozido, tomate cereja e azeite. Leve, saciante e rico em fibras."
  },
  {
    id: 14,
    nome: "Sopa de Legumes Detox",
    tipo: "alimentação",
    objetivo: "emagrecimento",
    dificuldade: "médio",
    imagem: "https://images.unsplash.com/photo-1547592180-85f173990554?w=400&h=300&fit=crop",
    descricao: "Abobrinha, cenoura, chuchu e ervas frescas cozidos lentamente. Baixa caloria e alta nutrição."
  },
  {
    id: 15,
    nome: "Wrap de Alface com Atum",
    tipo: "alimentação",
    objetivo: "emagrecimento",
    dificuldade: "fácil",
    imagem: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop",
    descricao: "Folhas de alface como base, recheadas com atum, cenoura ralada e iogurte natural. Prático e leve."
  },

  // ---------- RECEITAS - MANUTENÇÃO ----------
  {
    id: 16,
    nome: "Bowl de Iogurte com Frutas e Granola",
    tipo: "alimentação",
    objetivo: "manutenção",
    dificuldade: "fácil",
    imagem: "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400&h=300&fit=crop",
    descricao: "Iogurte natural, granola sem açúcar, morango e banana. Equilíbrio entre proteína, fibra e energia."
  },
  {
    id: 17,
    nome: "Macarrão Integral com Legumes",
    tipo: "alimentação",
    objetivo: "manutenção",
    dificuldade: "médio",
    imagem: "https://images.unsplash.com/photo-1645112411341-6c4fd023714a?w=400&h=300&fit=crop",
    descricao: "Macarrão integral, abobrinha, tomate e azeite com manjericão. Refeição balanceada para o dia a dia."
  }
];