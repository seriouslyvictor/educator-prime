/* ===========================
   simulador.js — Simulador Fitness GreenFit
   (Requisito de JS: interação com o DOM,
   cálculo de IMC/TMB e geração de sugestão dinâmica)
=========================== */

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('simulador-form');
  const resultado = document.getElementById('simulador-resultado');
  const placeholder = document.getElementById('simulador-placeholder');

  if (!form) return;

  const campos = {
    peso: document.getElementById('peso'),
    altura: document.getElementById('altura'),
    idade: document.getElementById('idade'),
    sexo: document.getElementById('sexo'),
    objetivo: document.getElementById('objetivo'),
    nivel: document.getElementById('nivel')
  };

  /* =========================================================
     1. VALIDAÇÃO
  ========================================================= */

  /**
   * Valida um campo numérico dentro de uma faixa aceitável.
   */
  function validarNumero(input, min, max) {
    const valor = parseFloat(input.value);
    const errorEl = input.parentElement.querySelector('.error-message');
    let mensagem = '';

    if (input.value.trim() === '') {
      mensagem = 'Este campo é obrigatório.';
    } else if (isNaN(valor) || valor < min || valor > max) {
      mensagem = `Informe um valor entre ${min} e ${max}.`;
    }

    if (mensagem) {
      input.classList.add('invalid');
      if (errorEl) errorEl.textContent = mensagem;
      return false;
    }

    input.classList.remove('invalid');
    if (errorEl) errorEl.textContent = '';
    return true;
  }

  /**
   * Valida um campo de seleção (select) que não pode ficar vazio.
   */
  function validarSelect(select) {
    const errorEl = select.parentElement.querySelector('.error-message');

    if (!select.value) {
      select.classList.add('invalid');
      if (errorEl) errorEl.textContent = 'Selecione uma opção.';
      return false;
    }

    select.classList.remove('invalid');
    if (errorEl) errorEl.textContent = '';
    return true;
  }

  function validarFormulario() {
    const validPeso = validarNumero(campos.peso, 30, 300);
    const validAltura = validarNumero(campos.altura, 100, 250);
    const validIdade = validarNumero(campos.idade, 10, 100);
    const validSexo = validarSelect(campos.sexo);
    const validObjetivo = validarSelect(campos.objetivo);
    const validNivel = validarSelect(campos.nivel);

    return validPeso && validAltura && validIdade && validSexo && validObjetivo && validNivel;
  }

  /* =========================================================
     2. CÁLCULOS (IMC e TMB)
  ========================================================= */

  /**
   * Calcula o Índice de Massa Corporal.
   * IMC = peso (kg) / altura (m)²
   */
  function calcularIMC(pesoKg, alturaCm) {
    const alturaM = alturaCm / 100;
    return pesoKg / (alturaM * alturaM);
  }

  /**
   * Classifica o IMC conforme faixas da OMS.
   */
  function classificarIMC(imc) {
    if (imc < 18.5) return 'Abaixo do peso';
    if (imc < 25) return 'Peso adequado';
    if (imc < 30) return 'Sobrepeso';
    if (imc < 35) return 'Obesidade grau I';
    if (imc < 40) return 'Obesidade grau II';
    return 'Obesidade grau III';
  }

  /**
   * Calcula a Taxa Metabólica Basal (TMB) usando a fórmula de Mifflin-St Jeor.
   * Homens:    TMB = 10*peso + 6.25*altura - 5*idade + 5
   * Mulheres:  TMB = 10*peso + 6.25*altura - 5*idade - 161
   */
  function calcularTMB(pesoKg, alturaCm, idade, sexo) {
    const base = 10 * pesoKg + 6.25 * alturaCm - 5 * idade;
    return sexo === 'masculino' ? base + 5 : base - 161;
  }

  /**
   * Aplica o fator de atividade sobre a TMB para estimar o
   * Gasto Energético Total Diário (GET).
   */
  function calcularGET(tmb, nivel) {
    const fatores = {
      sedentario: 1.2,
      leve: 1.375,
      moderado: 1.55,
      intenso: 1.725
    };
    return tmb * (fatores[nivel] || 1.2);
  }

  /* =========================================================
     3. LÓGICA DE RECOMENDAÇÃO (condicionais fixas)
  ========================================================= */

  /**
   * Retorna uma sugestão de treino com base no objetivo e nível.
   */
  function sugerirTreino(objetivo, nivel) {
    const treinos = {
      hipertrofia: {
        sedentario: 'Comece com treino full body 2x por semana, focando em técnica e cargas leves.',
        leve: 'Treino dividido em superior/inferior, 3x por semana, com progressão de carga semanal.',
        moderado: 'Treino A/B/C (peito-tríceps, costas-bíceps, pernas-ombro), 4x por semana.',
        intenso: 'Treino push/pull/legs com 5-6 sessões semanais, priorizando volume e intensidade.'
      },
      emagrecimento: {
        sedentario: 'Caminhadas de 20-30 minutos, 3x por semana, com aumento gradual de ritmo.',
        leve: 'Treino funcional leve + caminhada, 3-4x por semana, intensidade moderada.',
        moderado: 'HIIT 3x por semana intercalado com treino de força full body 2x por semana.',
        intenso: 'Combinação de HIIT, treino de força e cardio de baixa intensidade em 5-6 dias.'
      },
      manutenção: {
        sedentario: 'Caminhadas leves e alongamentos diários para criar o hábito de movimento.',
        leve: 'Treino full body 2x por semana + uma atividade recreativa de sua escolha.',
        moderado: 'Treino full body 3x por semana, alternando força e mobilidade.',
        intenso: 'Treino full body 4x por semana combinando força, mobilidade e cardio leve.'
      }
    };

    return treinos[objetivo]?.[nivel] || 'Mantenha-se ativo com pelo menos 150 minutos de atividade física por semana.';
  }

  /**
   * Retorna uma sugestão de alimentação com base no objetivo.
   */
  function sugerirAlimentacao(objetivo) {
    const dietas = {
      hipertrofia: 'Aumente o consumo de proteínas (carnes magras, ovos, leguminosas) e carboidratos complexos (arroz integral, batata doce, aveia). Faça 4-5 refeições ao dia.',
      emagrecimento: 'Priorize vegetais, proteínas magras e grãos integrais, reduzindo ultraprocessados e açúcares. Mantenha boa hidratação e refeições regulares para evitar exageros.',
      manutenção: 'Mantenha uma alimentação variada e equilibrada, com proporções similares de proteínas, carboidratos e gorduras boas, ajustando porções conforme a fome.'
    };

    return dietas[objetivo] || 'Busque uma alimentação variada, rica em vegetais, proteínas magras e grãos integrais.';
  }

  /**
   * Retorna 2 itens do catálogo (data.js) relacionados ao objetivo,
   * caso o array catalogoSaude esteja disponível.
   */
  function itensRelacionados(objetivo) {
    if (typeof catalogoSaude === 'undefined') return [];

    const relacionados = [];
    for (const item of catalogoSaude) {
      if (item.objetivo === objetivo) {
        relacionados.push(item);
      }
      if (relacionados.length === 3) break;
    }
    return relacionados;
  }

  /* =========================================================
     4. RENDERIZAÇÃO DO RESULTADO NO DOM
  ========================================================= */

  function renderizarResultado(dados) {
    const { peso, altura, idade, sexo, objetivo, nivel, imc, classificacaoIMC, tmb, get } = dados;

    const objetivoLabel = {
      hipertrofia: 'Ganho de massa muscular',
      emagrecimento: 'Emagrecimento',
      manutenção: 'Manutenção do peso atual'
    }[objetivo];

    const treino = sugerirTreino(objetivo, nivel);
    const alimentacao = sugerirAlimentacao(objetivo);
    const relacionados = itensRelacionados(objetivo);

    let relacionadosHTML = '';
    if (relacionados.length > 0) {
      relacionadosHTML = `
        <div class="result-related">
          <h4>Sugestões do catálogo</h4>
          <ul class="related-list">
            ${relacionados.map(item => `
              <li>
                <span class="badge">${item.tipo === 'treino' ? 'Treino' : 'Receita'}</span>
                ${item.nome}
              </li>
            `).join('')}
          </ul>
          <a href="catalogo.html" class="btn btn-secondary btn-sm">Ver catálogo completo</a>
        </div>
      `;
    }

    resultado.innerHTML = `
      <div class="result-header">
        <span class="eyebrow">Seu plano personalizado</span>
        <h3>Objetivo: ${objetivoLabel}</h3>
      </div>

      <div class="result-metrics">
        <div class="metric-card">
          <span class="metric-label">IMC</span>
          <strong class="metric-value">${imc.toFixed(1)}</strong>
          <span class="metric-tag">${classificacaoIMC}</span>
        </div>
        <div class="metric-card">
          <span class="metric-label">Taxa Metabólica Basal</span>
          <strong class="metric-value">${Math.round(tmb)}</strong>
          <span class="metric-tag">kcal/dia em repouso</span>
        </div>
        <div class="metric-card">
          <span class="metric-label">Gasto energético estimado</span>
          <strong class="metric-value">${Math.round(get)}</strong>
          <span class="metric-tag">kcal/dia com atividade</span>
        </div>
      </div>

      <div class="result-block">
        <h4>Sugestão de treino</h4>
        <p>${treino}</p>
      </div>

      <div class="result-block">
        <h4>Sugestão de alimentação</h4>
        <p>${alimentacao}</p>
      </div>

      ${relacionadosHTML}

      <p class="result-disclaimer">
        Esta sugestão é gerada por regras fixas e tem caráter educativo.
        Consulte um profissional de saúde antes de iniciar qualquer programa de treino ou dieta.
      </p>
    `;

    placeholder.style.display = 'none';
    resultado.hidden = false;
    resultado.classList.remove('visible');
    // Pequeno delay para garantir a transição de fade-in
    requestAnimationFrame(() => {
      resultado.classList.add('visible');
    });

    resultado.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  /* =========================================================
     5. EVENTO DE SUBMIT
  ========================================================= */

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    if (!validarFormulario()) {
      return;
    }

    const peso = parseFloat(campos.peso.value);
    const altura = parseFloat(campos.altura.value);
    const idade = parseInt(campos.idade.value, 10);
    const sexo = campos.sexo.value;
    const objetivo = campos.objetivo.value;
    const nivel = campos.nivel.value;

    const imc = calcularIMC(peso, altura);
    const classificacaoIMC = classificarIMC(imc);
    const tmb = calcularTMB(peso, altura, idade, sexo);
    const get = calcularGET(tmb, nivel);

    renderizarResultado({ peso, altura, idade, sexo, objetivo, nivel, imc, classificacaoIMC, tmb, get });
  });

  // Remove a marcação de erro ao digitar novamente
  Object.values(campos).forEach((campo) => {
    if (!campo) return;
    const evento = campo.tagName === 'SELECT' ? 'change' : 'input';
    campo.addEventListener(evento, () => {
      campo.classList.remove('invalid');
      const errorEl = campo.parentElement.querySelector('.error-message');
      if (errorEl) errorEl.textContent = '';
    });
  });
});