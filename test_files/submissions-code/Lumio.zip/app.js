/* ════════════════════════════════════════════════════════
   LUMIO — app.js
   Gerenciamento de dados, LocalStorage e utilitários
════════════════════════════════════════════════════════ */

// ── DADOS DE DEMONSTRAÇÃO ─────────────────────────────────
const DEMO_DATA = {
  materias: [
    { id: 1, nome: 'Matemática',       cor: '#3B82F6', prioridade: 'alta',  tarefas: 5 },
    { id: 2, nome: 'Português',        cor: '#8B5CF6', prioridade: 'alta',  tarefas: 3 },
    { id: 3, nome: 'História',         cor: '#F59E0B', prioridade: 'media', tarefas: 4 },
    { id: 4, nome: 'Física',           cor: '#10B981', prioridade: 'media', tarefas: 2 },
    { id: 5, nome: 'Química',          cor: '#EF4444', prioridade: 'baixa', tarefas: 1 },
    { id: 6, nome: 'Desenvolvimento Web', cor: '#0EA5E9', prioridade: 'alta', tarefas: 6 }
  ],
  tarefas: [
    { id: 1, titulo: 'Lista de exercícios cap. 5',       materia: 'Matemática',       status: 'concluida',  data: '2026-06-10' },
    { id: 2, titulo: 'Redação sobre meio ambiente',       materia: 'Português',        status: 'concluida',  data: '2026-06-12' },
    { id: 3, titulo: 'Revisão da Revolução Francesa',    materia: 'História',         status: 'andamento',  data: '2026-06-15' },
    { id: 4, titulo: 'Exercícios de Cinemática',         materia: 'Física',           status: 'andamento',  data: '2026-06-16' },
    { id: 5, titulo: 'Simulado ENEM — Linguagens',       materia: 'Português',        status: 'pendente',   data: '2026-06-18' },
    { id: 6, titulo: 'Funções e gráficos',               materia: 'Matemática',       status: 'pendente',   data: '2026-06-19' },
    { id: 7, titulo: 'Termoquímica — exercícios',        materia: 'Química',          status: 'pendente',   data: '2026-06-20' },
    { id: 8, titulo: 'Projeto TCC — Lumio',              materia: 'Desenvolvimento Web', status: 'andamento', data: '2026-06-24' },
    { id: 9, titulo: 'Layout das páginas internas',      materia: 'Desenvolvimento Web', status: 'concluida', data: '2026-06-13' },
    { id: 10, titulo: 'Integração com LocalStorage',     materia: 'Desenvolvimento Web', status: 'pendente', data: '2026-06-22' }
  ],
  metas: [
    { id: 1, titulo: 'Estudar 15 horas esta semana', progresso: 68, total: 100, unidade: 'horas', dataLimite: '2026-06-21' },
    { id: 2, titulo: 'Concluir 20 exercícios de Matemática', progresso: 14, total: 20, unidade: 'exercícios', dataLimite: '2026-06-30' },
    { id: 3, titulo: 'Ler 3 capítulos de História', progresso: 2, total: 3, unidade: 'capítulos', dataLimite: '2026-06-18' },
    { id: 4, titulo: 'Finalizar módulo de CSS Avançado', progresso: 75, total: 100, unidade: '%', dataLimite: '2026-06-25' }
  ],
  cronograma: [
    { id: 1, dia: 'segunda', materia: 'Matemática',    horario: '08:00', duracao: 90 },
    { id: 2, dia: 'segunda', materia: 'Português',     horario: '10:00', duracao: 60 },
    { id: 3, dia: 'terca',   materia: 'História',      horario: '08:00', duracao: 90 },
    { id: 4, dia: 'terca',   materia: 'Física',        horario: '14:00', duracao: 60 },
    { id: 5, dia: 'quarta',  materia: 'Matemática',    horario: '09:00', duracao: 90 },
    { id: 6, dia: 'quarta',  materia: 'Química',       horario: '14:00', duracao: 60 },
    { id: 7, dia: 'quinta',  materia: 'Português',     horario: '08:00', duracao: 60 },
    { id: 8, dia: 'quinta',  materia: 'Desenvolvimento Web', horario: '14:00', duracao: 120 },
    { id: 9, dia: 'sexta',   materia: 'Física',        horario: '08:00', duracao: 90 },
    { id: 10, dia: 'sexta',  materia: 'Desenvolvimento Web', horario: '14:00', duracao: 90 }
  ],
  gamificacao: {
    xp: 780,
    nivel: 5,
    streak: 12,
    xpProximoNivel: 1000
  },
  estatisticas: {
    horasSemanais: [6.5, 8, 5, 9, 7, 4, 0],
    tarefasPorMateria: [5, 3, 4, 2, 1, 6],
    evolucaoMensal: [42, 58, 65, 72, 80, 88]
  }
};

// ── STORAGE ───────────────────────────────────────────────
const Storage = {
  get(key) {
    try {
      const v = localStorage.getItem(`lumio_${key}`);
      return v ? JSON.parse(v) : null;
    } catch { return null; }
  },
  set(key, value) {
    try { localStorage.setItem(`lumio_${key}`, JSON.stringify(value)); }
    catch (e) { console.warn('Storage error:', e); }
  },
  init() {
    if (!this.get('initialized')) {
      Object.entries(DEMO_DATA).forEach(([k, v]) => this.set(k, v));
      this.set('initialized', true);
      console.log('✅ Lumio: dados de demonstração carregados');
    }
  },
  reset() {
    Object.keys(DEMO_DATA).forEach(k => this.set(k, DEMO_DATA[k]));
    this.set('initialized', true);
  }
};

// ── TOAST ─────────────────────────────────────────────────
function showToast(msg, type = 'success') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const icon = type === 'success' ? 'ti-circle-check' : 'ti-alert-circle';
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<i class="ti ${icon}"></i><span>${msg}</span>`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3100);
}

// ── SIDEBAR ───────────────────────────────────────────────
function initSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const mainContent = document.querySelector('.main-content');
  const toggle = document.querySelector('.sidebar-toggle');
  if (!sidebar || !toggle) return;

  const collapsed = localStorage.getItem('lumio_sidebar_collapsed') === 'true';
  if (collapsed) {
    sidebar.classList.add('collapsed');
    mainContent?.classList.add('collapsed');
  }

  toggle.addEventListener('click', () => {
    const isCollapsed = sidebar.classList.toggle('collapsed');
    mainContent?.classList.toggle('collapsed', isCollapsed);
    localStorage.setItem('lumio_sidebar_collapsed', isCollapsed);
  });
}

// ── MODAL ─────────────────────────────────────────────────
function openModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add('open');
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove('open');
}
function initModals() {
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.classList.remove('open');
    });
  });
  document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.closest('.modal-overlay')?.classList.remove('open');
    });
  });
}

// ── ACTIVE NAV ────────────────────────────────────────────
function setActiveNav() {
  const page = location.pathname.split('/').pop() || 'app.html';
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('href') === page) item.classList.add('active');
  });
}

// ── GENERATE IDs ──────────────────────────────────────────
function genId(arr) {
  return arr.length ? Math.max(...arr.map(i => i.id)) + 1 : 1;
}

// ── FORMAT DATE ───────────────────────────────────────────
function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const today = new Date(); today.setHours(0,0,0,0);
  const target = new Date(dateStr + 'T00:00:00');
  return Math.ceil((target - today) / 86400000);
}

// ── PRIORIDADE LABEL ──────────────────────────────────────
function prioridadeBadge(p) {
  const map = {
    alta:  ['badge-red',    'Alta'],
    media: ['badge-orange', 'Média'],
    baixa: ['badge-muted',  'Baixa']
  };
  const [cls, label] = map[p] || ['badge-muted', p];
  return `<span class="badge ${cls}">${label}</span>`;
}

// ── STATUS LABEL ──────────────────────────────────────────
function statusBadge(s) {
  const map = {
    pendente:  ['badge-muted',   'Pendente'],
    andamento: ['badge-orange',  'Em andamento'],
    concluida: ['badge-green',   'Concluída']
  };
  const [cls, label] = map[s] || ['badge-muted', s];
  return `<span class="badge ${cls}">${label}</span>`;
}

// ── INIT ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  Storage.init();
  initSidebar();
  initModals();
  setActiveNav();
});
